const form = document.querySelector("#search-form");
const queryInput = document.querySelector("#query");
const sourceInput = document.querySelector("#source");
const maxPriceInput = document.querySelector("#max-price");
const resultsEl = document.querySelector("#results");
const noticeEl = document.querySelector("#notice");
const titleEl = document.querySelector("#results-title");
const countEl = document.querySelector("#result-count");

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[ch]);
}

function renderOffers(data) {
  titleEl.textContent = `Результаты: ${data.query}`;
  countEl.textContent = `${data.count} предложений`;
  noticeEl.textContent = data.notice;
  if (!data.offers.length) {
    resultsEl.className = "results empty";
    resultsEl.innerHTML = `<div class="empty-icon">⌕</div><b>В демоданных совпадений нет</b><p>Открой поиск на площадках ниже или попробуй другой запрос. Реальный сбор данных пока не подключён.</p>`;
    const links = (data.marketplace_searches || []).map(x =>
      `<a class="open-link" target="_blank" rel="noopener noreferrer" href="${escapeHtml(x.url)}">Искать на ${escapeHtml(x.source)} ↗</a>`
    ).join("");
    resultsEl.insertAdjacentHTML("beforeend", `<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin-top:12px">${links}</div>`);
    return;
  }
  resultsEl.className = "results";
  resultsEl.innerHTML = data.offers.map(o => `
    <article class="offer">
      <div><h3>${escapeHtml(o.title)}</h3>
        <div class="offer-meta"><span class="tag">${escapeHtml(o.source)}</span><span class="tag">${escapeHtml(o.kind)}</span><span>${escapeHtml(o.region)}</span></div>
      </div>
      <div class="price">${Number(o.price).toLocaleString("ru-RU")} <small>₽</small></div>
      <a class="open-link" href="${escapeHtml(o.url)}" target="_blank" rel="noopener noreferrer">Открыть источник ↗</a>
    </article>`).join("");
}

async function search() {
  const q = queryInput.value.trim();
  if (!q) return;
  titleEl.textContent = "Ищем предложения…";
  resultsEl.className = "results empty";
  resultsEl.innerHTML = "<b>Загружаем результаты</b>";
  const params = new URLSearchParams({q, source: sourceInput.value});
  if (maxPriceInput.value !== "") params.set("max_price", maxPriceInput.value);
  try {
    const response = await fetch(`/api/search?${params}`);
    if (!response.ok) throw new Error("Не удалось выполнить поиск");
    renderOffers(await response.json());
  } catch (err) {
    titleEl.textContent = "Ошибка поиска";
    resultsEl.className = "results empty";
    resultsEl.innerHTML = `<b>${escapeHtml(err.message)}</b><p>Проверь, запущен ли сервер.</p>`;
  }
}
form.addEventListener("submit", e => { e.preventDefault(); search(); });
document.querySelector("#apply-filters").addEventListener("click", search);
document.querySelectorAll("[data-query]").forEach(button => button.addEventListener("click", () => {
  queryInput.value = button.dataset.query;
  search();
}));
